package simpl.interpreter;

import java.util.HashMap;

public class Mem extends HashMap<Integer, Value> {

    private static final long serialVersionUID = -1155291135560730618L;
}
